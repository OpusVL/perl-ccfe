#!/bin/sh
#
#  CCFE configuration file editor
#  Copyright (C) 2012 Massimo Loschi
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#  Author: Massimo Loschi <ccfedevel@gmail.com>
#

# Change Fn keys labels in CCFE messages definition file.

MSG_FNAME=$1
NOW=$2
shift 2

sed -e 's/\(^ *KEY_F1_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$1"'\3/' \
    -e 's/\(^ *KEY_F2_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$2"'\3/' \
    -e 's/\(^ *KEY_F3_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$3"'\3/' \
    -e 's/\(^ *KEY_F4_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$4"'\3/' \
    -e 's/\(^ *KEY_F5_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$5"'\3/' \
    -e 's/\(^ *KEY_F6_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$6"'\3/' \
    -e 's/\(^ *KEY_F7_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$7"'\3/' \
    -e 's/\(^ *KEY_F8_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$8"'\3/' \
    -e 's/\(^ *KEY_F9_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$9"'\3/' \
    -e 's/\(^ *KEY_F10_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$10"'\3/' \
    -e 's/\(^ *KEY_F11_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$11"'\3/' \
    -e 's/\(^ *KEY_F12_LABEL *= *"\)\(.*\)\(" *$\)/\1'"$12"'\3/' \
    $MSG_FNAME.$NOW > $MSG_FNAME
