package lethal;

# A dummy package showing how we can trivially subclass autodie
# to our tastes.

use parent qw(autodie);

1;
